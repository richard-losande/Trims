﻿using Dapper;
using Progress.DataAccess.Entities;
using Sprout.Services.Data.Configurations;

namespace Progress.DataAccess.Repositories
{
    public class UserRepository : RepositoryBase<int, UserEntity>, IUserRepository
    {
        public UserRepository(IDbConfiguration dbConfiguration) : base(dbConfiguration)
        {
        }
        public async Task<UserEntity> GetUserByIdAsync (int id)
        {
            return new UserEntity
            {
                Id = id,
                Email  =  "John Doe"
            };
        }

        public async Task<int?> InsertUser(UserEntity input)
        {
            var db = await _dbConfiguration.GetConnectionAsync();
            return await db.InsertAsync(input);
        }
    }
}
