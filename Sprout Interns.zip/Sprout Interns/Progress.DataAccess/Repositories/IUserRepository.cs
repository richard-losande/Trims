﻿using Progress.DataAccess.Entities;

namespace Progress.DataAccess.Repositories
{
    public interface IUserRepository : IRepositoryBase<int, UserEntity>
    {
        Task<UserEntity> GetUserByIdAsync(int id);
        Task<int?> InsertUser(UserEntity input);
    }
}
