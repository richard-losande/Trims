﻿using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using Sprout.Services.Data.Configurations;
using System.Data;

namespace Progress.DataAccess.Configurations
{
    public class DbConfiguration : IDbConfiguration
    {
        private readonly IConfiguration _configuration;
        private string _connectionString;
        public DbConfiguration(IConfiguration configuration)
        {
            _configuration = configuration ?? throw new ArgumentNullException(nameof(configuration));
        }
        public async Task<IDbConnection> GetConnectionAsync()
        {
            if (!string.IsNullOrWhiteSpace(_connectionString))
                return new SqlConnection(_connectionString);

            _connectionString = _configuration.GetConnectionString("ClientDbConnection");
            return new SqlConnection(_connectionString);
        }
    }
}
