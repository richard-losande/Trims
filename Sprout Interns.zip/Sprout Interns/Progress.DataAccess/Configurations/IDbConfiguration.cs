using System.Data;
using System.Threading.Tasks;

namespace Sprout.Services.Data.Configurations
{
	public interface IDbConfiguration
	{
		/// <summary>
		/// Get database connection
		/// </summary>
		/// <returns>Returns database connection</returns>
		Task<IDbConnection> GetConnectionAsync();
	}
}
