﻿using Progress.DataAccess.Repositories;
using Sprout.Services.Data.Configurations;

namespace Progress.DataAccess.Contexts
{
    public class DbContext : IDbContext
    {
        protected readonly IDbConfiguration _dbConfiguration;

        public DbContext(IDbConfiguration dbConfiguration)
        {
            _dbConfiguration = dbConfiguration;
        }
        //Add here your repository
        public IUserRepository UserRepository => new UserRepository(_dbConfiguration);
    }
}

