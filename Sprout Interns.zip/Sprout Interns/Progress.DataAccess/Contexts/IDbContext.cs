﻿using Progress.DataAccess.Repositories;

namespace Progress.DataAccess.Contexts
{
    public interface IDbContext
    {
        IUserRepository UserRepository { get;}
    }
}
