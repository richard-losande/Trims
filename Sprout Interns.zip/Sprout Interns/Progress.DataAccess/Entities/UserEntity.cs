﻿using Dapper;

namespace Progress.DataAccess.Entities
{
    [Table("Users")]
    public class UserEntity
    {
        [Key]
        public int Id { get; set; }
        public string Email { get; set; }
        public byte[] Password { get; set; }
        public int RoleId { get; set; }
    }
}
