﻿using System.Data;

namespace Progress.DataAccess
{
    public interface IRepositoryBase<TPrimaryKey, TEntity>
    {
        Task<TEntity> GetByIdAsync(TPrimaryKey id);
        Task<IEnumerable<TEntity>> GetAllAsync();
        Task<IEnumerable<TEntity>> GetListAsync(object parameters);
        Task<IEnumerable<TEntity>> GetListAsync(string where, object parameters = null);
        Task<IEnumerable<TEntity>> GetListPagedAsync(int pageNumber, int rowsPerPage, string conditions, string orderBy, object parameters = null);
        Task<TEntity> GetSingleAsync(string where, object parameters = null);
        Task<TEntity> GetFirstAsync(string where, object parameters = null);

        Task<TPrimaryKey> InsertAsync(TEntity toBeInserted, IDbTransaction dbTransaction = null);
        Task UpdateAsync(TEntity toBeUpdated, IDbTransaction dbTransaction = null);
        Task<int> DeleteAsync(TEntity toBeDeleted, IDbTransaction dbTransaction = null);
        Task<IEnumerable<T>> QueryAsync<T>(string sql, object param = null, IDbTransaction dbTransaction = null);
        Task ExecuteAsync(string sql, object param = null, IDbTransaction dbTransaction = null);
    }
}
