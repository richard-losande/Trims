﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Progress.DataAccess.Configurations;
using Progress.DataAccess.Repositories;
using Sprout.Services.Data.Configurations;

namespace Progress.DataAccess
{
    public static class DependencyInjection
    {
        public static IServiceCollection AddDataAccess(this IServiceCollection services)
        {
            services.AddTransient<IUserRepository, UserRepository>();
            services.AddTransient<IDbConfiguration, DbConfiguration>();
            return services;
        }
    }
}
