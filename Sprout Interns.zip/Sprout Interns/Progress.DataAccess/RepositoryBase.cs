﻿using Sprout.Services.Data.Configurations;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Dapper;

namespace Progress.DataAccess
{
	public abstract class RepositoryBase<TPrimaryKey, TEntity> : IRepositoryBase<TPrimaryKey, TEntity>
	{
		protected readonly IDbConfiguration _dbConfiguration;

		protected RepositoryBase(IDbConfiguration dbConfiguration)
		{
			_dbConfiguration = dbConfiguration ?? throw new ArgumentNullException(nameof(dbConfiguration));
		}
		public virtual async Task<int> DeleteAsync(TEntity toBeDeleted, IDbTransaction dbTransaction = null)
		{
			using var conn = await _dbConfiguration.GetConnectionAsync();
			return await conn.DeleteAsync(toBeDeleted, dbTransaction);
		}

		public virtual async Task<IEnumerable<TEntity>> GetAllAsync()
		{
			using var conn = await _dbConfiguration.GetConnectionAsync();
			return await conn.GetListAsync<TEntity>();
		}

		public virtual async Task<TEntity> GetByIdAsync(TPrimaryKey id)
		{
			using var conn = await _dbConfiguration.GetConnectionAsync();
			return await conn.GetAsync<TEntity>(id);
		}

		public virtual async Task<TEntity> GetFirstAsync(string where, object parameters = null)
		{
			using var conn = await _dbConfiguration.GetConnectionAsync();
			var tableName = GetTableAttributeName();
			if (string.IsNullOrEmpty(tableName))
				throw new ArgumentNullException($"Table Attribute has not been set with this entity: {typeof(TEntity)}");

			return await conn.QueryFirstOrDefaultAsync<TEntity>($"SELECT TOP 1 * FROM {tableName} {@where}", parameters);
		}

		public virtual async Task<IEnumerable<TEntity>> GetListAsync(object parameters)
		{
			using var conn = await _dbConfiguration.GetConnectionAsync();
			return await conn.GetListAsync<TEntity>(parameters);
		}

		public virtual async Task<IEnumerable<TEntity>> GetListAsync(string where, object parameters = null)
		{
			using var conn = await _dbConfiguration.GetConnectionAsync();
			return await conn.GetListAsync<TEntity>(@where, parameters);
		}

		public virtual async Task<IEnumerable<TEntity>> GetListPagedAsync(int pageNumber, int rowsPerPage, string conditions, string orderBy, object parameters = null)
		{
			using var conn = await _dbConfiguration.GetConnectionAsync();
			return await conn.GetListPagedAsync<TEntity>(pageNumber, rowsPerPage, conditions, orderBy, parameters);
		}

		public virtual async Task<TEntity> GetSingleAsync(string where, object parameters = null)
		{
			using var conn = await _dbConfiguration.GetConnectionAsync();
			var tableName = GetTableAttributeName();
			if (tableName == string.Empty)
				throw new ArgumentNullException($"Table Attribute has not been set with this entity: {typeof(TEntity)}");

			return await conn.QuerySingleOrDefaultAsync<TEntity>($"SELECT TOP 1 * FROM {tableName} {@where}", parameters);
		}

		public virtual async Task<TPrimaryKey> InsertAsync(TEntity toBeInserted, IDbTransaction dbTransaction = null)
		{
			using var conn = await _dbConfiguration.GetConnectionAsync();
			return await conn.InsertAsync<TPrimaryKey, TEntity>(toBeInserted, dbTransaction);
		}

		public virtual async Task UpdateAsync(TEntity toBeUpdated, IDbTransaction dbTransaction = null)
		{
			using var conn = await _dbConfiguration.GetConnectionAsync();
			await conn.UpdateAsync(toBeUpdated, dbTransaction);
		}

		public virtual async Task<IEnumerable<T>> QueryAsync<T>(string sql, object param = null, IDbTransaction dbTransaction = null)
		{
			using var conn = await _dbConfiguration.GetConnectionAsync();
			return await conn.QueryAsync<T>(sql, param, dbTransaction);
		}

		public virtual async Task ExecuteAsync(string sql, object param = null, IDbTransaction dbTransaction = null)
		{
			using var conn = await _dbConfiguration.GetConnectionAsync();
			await conn.ExecuteAsync(sql, param, dbTransaction);
		}

		protected string GetTableAttributeName()
		{
			if (typeof(TEntity).GetCustomAttributes(typeof(TableAttribute), true).FirstOrDefault() is TableAttribute tableAttribute)
			{
				return tableAttribute.Name;
			}

			return string.Empty;
		}
	}

}
