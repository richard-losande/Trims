using Progress.Common.Entities;
using Progress.Common.Exceptions;
using System;
using System.Runtime.Serialization;

namespace Progress.Common.Exceptions
{
	[Serializable]
	public class NotFoundException : BaseException
    {
        public NotFoundException()
        {
        }

        public NotFoundException(ErrorResponse errorResponse) : base(errorResponse)
        {
        }

        protected NotFoundException(SerializationInfo info, StreamingContext context)
	        : base(info, context)
        {
        }
	}
}
