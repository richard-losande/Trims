using Progress.Common.Entities;
using Progress.Common.Exceptions;
using System;
using System.Runtime.Serialization;

namespace Progress.Common.Exceptions
{
	[Serializable]
	public class UnauthorizedException : BaseException
    {
        public UnauthorizedException()
        {
        }

        public UnauthorizedException(ErrorResponse errorResponse) : base(errorResponse)
        {
        }

		protected UnauthorizedException(SerializationInfo info, StreamingContext context)
	        : base(info, context)
        {
        }
	}
}
