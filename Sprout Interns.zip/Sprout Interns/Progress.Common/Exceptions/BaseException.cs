using Progress.Common.Entities;
using System;
using System.Runtime.Serialization;

namespace Progress.Common.Exceptions
{
	[Serializable]
    public abstract class BaseException : Exception
    {
	    public ErrorResponse ErrorResponse { get; set; }

        protected BaseException() : base(string.Empty)
        {
        }

        protected BaseException(ErrorResponse errorResponse)
        {
            ErrorResponse = errorResponse;
        }

        protected BaseException(SerializationInfo info, StreamingContext context)
	        : base(info, context)
        {
        }

	}
}
