using Progress.Common.Entities;
using Progress.Common.Exceptions;
using System;
using System.Runtime.Serialization;

namespace Progress.Common.Exceptions
{
	[Serializable]
	public class ForbiddenException : BaseException
    {
        public ForbiddenException()
        {
        }

        public ForbiddenException(ErrorResponse errorResponse) : base(errorResponse)
        {
        }

        protected ForbiddenException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
	}
}
