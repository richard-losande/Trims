using Progress.Common.Entities;
using System;
using System.Runtime.Serialization;

namespace Progress.Common.Exceptions
{
	[Serializable]
    public class BusinessException : BaseException
    {
        public BusinessException()
        {
        }

        public BusinessException(ErrorResponse errorResponse) : base(errorResponse)
        {
        }

        protected BusinessException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
	}
}
