using Progress.Common.Entities;
using Progress.Common.Exceptions;
using System;
using System.Runtime.Serialization;

namespace Progress.Common.Exceptions
{
	[Serializable]
	public class ValidationException : BaseException
    {
        public ValidationException()
        {
        }

        public ValidationException(ErrorResponse errorResponse) : base(errorResponse)
        {
        }

        protected ValidationException(SerializationInfo info, StreamingContext context)
	        : base(info, context)
        {
        }
	}
}
