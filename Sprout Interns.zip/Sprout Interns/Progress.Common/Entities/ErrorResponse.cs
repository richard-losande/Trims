using System.Collections.Generic;

namespace Progress.Common.Entities
{
	public class ErrorResponse
	{
		public ErrorResponse(string message, string referenceKey = null, int? code = null, string codeInfo = null)
		{
			Message = message;
			ReferenceKey = referenceKey;
			Code = code;
			CodeInfo = codeInfo;
		}

		public ErrorResponse()
		{
		}

		public string Message { get; set; }
		public string ReferenceKey { get; set; }
		public int? Code { get; set; }
		public string CodeInfo { get; set; }
		public IDictionary<string, string[]> Errors { get; set; }
	}
}
