﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Progress.Business.ServiceCollection.Implementation;
using Progress.DataAccess.Contexts;

namespace Progress.Business
{
    public static class DependecyInjection
    {
        public static IServiceCollection AddBusiness(this IServiceCollection services)
        {
            services.AddTransient<IUserService, UserService>();
            services.AddScoped<IDbContext, DbContext>();
            return services;
        }
    }
}
