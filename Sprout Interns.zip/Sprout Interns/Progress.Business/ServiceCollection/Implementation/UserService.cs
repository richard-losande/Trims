﻿using Progress.Business.DataTransferObject;
using Progress.DataAccess.Contexts;
using Progress.DataAccess.Entities;

namespace Progress.Business.ServiceCollection.Implementation
{
    public class UserService : IUserService
    {
        private readonly IDbContext _dbContext;
        public UserService(IDbContext dbContext)
        {
            _dbContext = dbContext;
        }
        public async Task<UserOutputDto> GetUserByIdAsync(int id)
        {
            var response = await _dbContext.UserRepository.GetUserByIdAsync(id);
            return new UserOutputDto
            {
                Id = response.Id,
                Name = response.Email
            };
        }

        public async Task<int?> InsertUser(UserInputDto input)
        {
            var userParameter = new UserEntity()
            {
                Email = input.Email,
                Password = ConvertStringToByteArray(input.Password),
                RoleId = 1,
            };
            return await _dbContext.UserRepository.InsertUser(userParameter);
        }
        private static byte[] ConvertStringToByteArray(string strValue)
        {
            var encoding = new System.Text.ASCIIEncoding();
            return encoding.GetBytes(strValue);
        }
    }
}
