﻿using Progress.Business.DataTransferObject;

namespace Progress.Business.ServiceCollection.Implementation
{
    public interface IUserService
    {
        Task<UserOutputDto> GetUserByIdAsync(int id);
        Task<int?> InsertUser(UserInputDto input);
    }
}
