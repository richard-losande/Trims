﻿namespace Progress.Business.DataTransferObject
{
    public class UserInputDto
    {
        public string Email { get; set; }
        public string Password { get; set; }
        public int RoleId { get; set; }
    }
}
