﻿namespace Progress.Business.DataTransferObject
{
    public class UserOutputDto
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
