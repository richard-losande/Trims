﻿using Microsoft.AspNetCore.Mvc;
using Progress.Business.DataTransferObject;
using Progress.Business.ServiceCollection.Implementation;
using Progress.Common.Entities;

namespace Progress.Controllers
{
    [ApiVersion("1")]
    [ApiVersion("2")]
    [Route("api/v{version:apiVersion}/[controller]")]
    [ApiController]
    public class UsersController : Controller
    {
		private readonly IUserService _userService;
		public UsersController(IUserService userService)
        {
            _userService = userService;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        [ProducesResponseType(typeof(UserOutputDto), StatusCodes.Status200OK)]
		[ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status500InternalServerError)]
        [ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status404NotFound)]
        [MapToApiVersion("1")]
		[HttpGet("{id}")]
		public async Task<IActionResult> GetUserById(int id)
		{
			return Ok(await _userService.GetUserByIdAsync(id));
		}
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        [ProducesResponseType(typeof(UserOutputDto), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status500InternalServerError)]
        [ProducesResponseType(typeof(ErrorResponse), StatusCodes.Status404NotFound)]
        [MapToApiVersion("1")]
        [HttpPost]
        public async Task<IActionResult> InsertUsers([FromBody] UserInputDto input)
        {
            return Ok(await _userService.InsertUser(input));
        }
    }
}
