using Microsoft.AspNetCore.Mvc;
using Microsoft.OpenApi.Models;
using Progress.Business;
using Progress.DataAccess;
using Progress.Swagger;
using Swashbuckle.AspNetCore.SwaggerGen;
using System.Reflection;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddApiVersioning();
builder.Services.AddSwaggerGen(c =>
{
    OpenApiInfo v1Info = new()
    {
        Title = "Progression",
        Version = "v1",
        Description = "This REST API will be the source of all data related to Progression.",
        Contact = new OpenApiContact { Email = "dummyaccount@gmail.com", Name = "Progress" }
    };

    OpenApiInfo v2Info = new() { Title = "Progression", Version = "v2" };

    c.OperationFilter<RemoveVersionFromParameter>();
    c.DocumentFilter<ReplaceVersionWithExactValueInPath>();
    string xmlPathFileName = "Progression.Business.xml";

    c.ResolveConflictingActions(apiDescriptions => apiDescriptions.First());
    //Commented the below code first . Implement once ready for JWT Bearer authentication
    c.SwaggerDoc("v1", v1Info);

    c.SwaggerDoc("v2", v2Info);

    // Ensure the routes are added to the right Swagger doc
    c.DocInclusionPredicate((version, desc) =>
    {
        if (!desc.TryGetMethodInfo(out MethodInfo methodInfo)) return false;
        var versions = methodInfo.DeclaringType
            .GetCustomAttributes(true)
            .OfType<ApiVersionAttribute>()
            .SelectMany(attr => attr.Versions);
        return versions.Any(v => $"v{v}" == version);
    });

    c.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
    {
        In = ParameterLocation.Header,
        Description = "Please insert JWT with Bearer into field",
        Name = "Authorization",
        Type = SecuritySchemeType.ApiKey
    });
    c.AddSecurityRequirement(new OpenApiSecurityRequirement {
                    {
                        new OpenApiSecurityScheme
                        {
                            Reference = new OpenApiReference
                            {
                                Type = ReferenceType.SecurityScheme,
                                Id = "Bearer"
                            }
                        },
                        Array.Empty<string>() }
                });

    var xmlFile = $"{Assembly.GetExecutingAssembly().GetName().Name}.xml";
    var xmlPath = Path.Combine(AppContext.BaseDirectory, xmlFile);
    var xmlPath2 = Path.Combine(AppContext.BaseDirectory, xmlPathFileName);

    //c.IncludeXmlComments(xmlPath);
    //c.IncludeXmlComments(xmlPath2);
});
builder.Services.AddBusiness();
builder.Services.AddDataAccess();
var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();
