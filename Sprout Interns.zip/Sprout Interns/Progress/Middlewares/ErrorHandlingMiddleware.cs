using Newtonsoft.Json;
using Progress.Common.Entities;
using Progress.Common.Exceptions;
using System.Net;

namespace Progress.Middlewares
{
    /// <summary>
    /// Global error handling middleware for the whole app.
    /// We can override the invoke method if we have specific logic for this service
    /// </summary>
    public class ErrorHandlingMiddleware
    {
        private readonly RequestDelegate _next;
        private readonly ILogger<ErrorHandlingMiddleware> _logger;

        public ErrorHandlingMiddleware(RequestDelegate next, ILogger<ErrorHandlingMiddleware> logger)
        {
            _next = next;
            _logger = logger;
        }

        public virtual async Task Invoke(HttpContext context /* other dependencies */)
        {
            try
            {
                await _next(context);
            }
            catch (BaseException ex)
            {
                await HandleExceptionAsync(context, ex);
            }
            catch (Exception ex)
            {
                await HandleExceptionAsync(context, ex);
            }

        }

        /// <summary>
        /// Handled exception will be executed here.
        /// </summary>
        /// <param name="context"></param>
        /// <param name="ex"></param>
        /// <returns></returns>
        private static async Task HandleExceptionAsync(HttpContext context, BaseException ex)
        {
            var code = ex switch
            {
                NotFoundException _ => HttpStatusCode.NotFound,
                UnauthorizedException _ => HttpStatusCode.Unauthorized,
                ValidationException _ => HttpStatusCode.UnprocessableEntity,
                ForbiddenException _ => HttpStatusCode.Forbidden,
                BusinessException _ => HttpStatusCode.InternalServerError,
                _ => HttpStatusCode.InternalServerError
            };

            var result = string.Empty;
            if (!string.IsNullOrEmpty(ex.Message))
            {
                result = JsonConvert.SerializeObject(ex.ErrorResponse);
            }

            context.Response.ContentType = "application/json";
            context.Response.StatusCode = (int)code;
            await context.Response.WriteAsync(result);
        }

        /// <summary>
        /// Unhandled exception will be executed here.
        /// </summary>
        /// <param name="context"></param>
        /// <param name="ex"></param>
        /// <returns></returns>
        private async Task HandleExceptionAsync(HttpContext context, Exception ex)
        {
            var errorReferenceKey = Guid.NewGuid().ToString();
            const string baseMessage = "A unhandled exception has occurred";
            var result = new ErrorResponse(baseMessage, errorReferenceKey);
            var resultString = JsonConvert.SerializeObject(result);
            _logger.LogError(ex, $"{baseMessage} - {result.ReferenceKey}");
            context.Response.ContentType = "application/json";
            context.Response.StatusCode = (int)HttpStatusCode.InternalServerError;
            await context.Response.WriteAsync(resultString);
        }
    }
}
